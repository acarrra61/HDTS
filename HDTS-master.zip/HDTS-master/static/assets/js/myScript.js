//alert("Hello, Welcome to JavaScript");
$(function() {
  $(document).ready(function() {
    $('#example').DataTable();
  });
});

